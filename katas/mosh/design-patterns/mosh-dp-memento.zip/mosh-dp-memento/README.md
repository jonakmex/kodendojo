# Kata — Memento Pattern (Java, Gradle)


Practice the **Memento** design pattern by implementing `Originator`, `Memento`, and `Caretaker` so that the provided test passes.
![Memento Pattern](assets/memento.png)

---

## 1) What you get

- A Gradle project (Java) with tests.
- A **`.git/` repository inside the project** with two branches:
  - **`start`** → the starting point you will work from.
  - **`solution`** → one proposed solution for comparison.
- **Do not modify** the test: `com.dp.memento.EditorTest`. At the end, it must pass.

> ⚠️ If you unzip with Finder and the `.git/` folder disappears, unzip from the terminal (keeps dotfiles):
> ```bash
> unzip mosh-dp-memento.zip
> ```

---

## 2) Quick refresher — Memento Pattern

The **Memento** pattern captures and externalizes an object’s internal state so that the object can be **restored** to that state later, **without exposing** its internals.

- **Originator**: object that has the state (`content`). Creates a **Memento** with its current state and can **restore** the state from a memento.
- **Memento**: value object that **stores a snapshot** of the originator’s state.
- **Caretaker**: manages the **history stack** of mementos (push/pop) but **doesn’t inspect** their internals.

Use cases: undo/redo, checkpoints, transactional rollbacks, editor history.
![Memento Pattern](assets/solution.png)

---

## 3) Prerequisites

- **Java 21+** available on your PATH.
- Gradle Wrapper is included or can be generated (`./gradlew wrapper`).

Check:
```bash
java -version
```

---

## 4) Getting started (recipe)

```bash
# 1) Unzip and enter the project
unzip mosh-dp-memento.zip
cd mosh-dp-memento

# 2) Make sure the repo has the two branches
git branch         # should show: start, solution
git checkout start # work from the start branch

# 3) (first time) prepare the wrapper if needed
./gradlew wrapper

# 4) Run tests — they should fail at first
./gradlew test
```

> Your goal is to implement the pattern so that **`com.dp.memento.EditorTest` passes**.

---

## 5) What to implement

- **Originator** (e.g., `Editor`, holds `content: String`)
  - `createState()` → returns a **Memento** with current `content`.
  - `restore(state)` → restores the `content` from a memento.
- **Memento**
  - Immutable object that contains `content: String` (the snapshot).
- **Caretaker**
  - Holds a list/stack of **Memento**.
  - `push(state)` and `pop()` to manage undo history.

> Keep the **Memento** opaque to the caretaker (no leaking internals).

Re-run tests as you work:
```bash
./gradlew test
```

---

## 6) Verify & compare with the solution

When your tests are green, you can compare with the proposed solution:

```bash
# Show a diff between your work and the solution branch
git diff start..solution

# Or switch to the solution to inspect it
git checkout solution
```

Return to your work any time:
```bash
git checkout start
```

---

## 7) Expected result

- The test **`com.dp.memento.EditorTest`** passes without changes.
- You have a working **Memento** implementation (Originator ↔ Memento ↔ Caretaker).
- You understand how to create/restore snapshots and manage history.

---

## 8) Troubleshooting

- **`.git/` missing after unzip** → unzip via terminal (`unzip file.zip`) to retain dotfiles.
- **Java not found** → install Temurin/OpenJDK 21 and retry `java -version`.
- **Gradle issues** → run `./gradlew --version`, then `./gradlew clean test`.

Happy practicing! 🎯
